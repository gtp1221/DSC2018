# Week 1 Agenda

## Action Items

### 1. Introductions  
	a. Name   
	b. Team   
	c. Previous Experience  
	d. Impression of 100  
	e. Intention for Accelerator  
### 2. Setting Breakout Expectations  
	a. Cadence  
	b. Come Prepared  
	c. Collaboration  
	d. Missed Break Outs  
### 3. Clone Breakout Repo
### 4. Week 1 Concepts/Phase 100 Q&A

## Resources

Github Repo: https://github.com/DanPiltzer/2018HomegrownBreakouts